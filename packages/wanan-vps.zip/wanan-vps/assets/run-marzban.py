#!/usr/bin/env python3
"""Keep the upstream launcher, disabling Uvicorn request-line access logging."""
from pathlib import Path
import runpy


def launch(main_path=None):
    import uvicorn
    main_path = Path(main_path or 'main.py').resolve(strict=True)
    original = uvicorn.run
    def without_request_lines(*args, **kwargs):
        kwargs['access_log'] = False
        return original(*args, **kwargs)
    uvicorn.run = without_request_lines
    try:
        print('wanan-vps: Uvicorn access logging disabled; operational logs retained.', flush=True)
        runpy.run_path(str(main_path), run_name='__main__')
    finally:
        uvicorn.run = original


if __name__ == '__main__':
    launch()
