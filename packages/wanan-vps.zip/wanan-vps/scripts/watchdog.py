#!/usr/bin/env python3
"""Bounded server-side recovery; never changes Reality or client rules."""
import datetime
import argparse
import json
import pathlib
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor

STATE = pathlib.Path('/var/lib/wanan-vps-watchdog/state.json')


def run(args, timeout=12):
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        return p.returncode == 0, p.stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        return False, ''


def eligible(state, key, bad, now):
    count_key = key + '_failures'
    state[count_key] = state.get(count_key, 0) + 1 if bad else 0
    day = datetime.datetime.fromtimestamp(now, datetime.timezone.utc).date().isoformat()
    if state.get('day') != day:
        state.update(day=day, actions=0)
    return (bad and state[count_key] >= 3 and state.get('actions', 0) < 2
            and now - state.get('last_action', 0) >= 1800)


def dns(host):
    return run(['getent', 'ahostsv4', host], 8)[0]


def probe_reality():
    # Probe the configured target with correct SNI and certificate verification.
    config = json.loads(pathlib.Path('/var/lib/marzban/xray_config.json').read_text())
    results = []
    for inbound in config.get('inbounds', []):
        reality = inbound.get('streamSettings', {}).get('realitySettings')
        if not reality:
            continue
        target = reality.get('target') or reality.get('dest')
        if not isinstance(target, str) or ':' not in target:
            results.append({'ok': False, 'error': 'unsupported target format'})
            continue
        host, port = target.rsplit(':', 1)
        for name in reality.get('serverNames', []):
            try:
                # curl bounds DNS as well as connect/TLS time; require TLS1.3.
                ok, out = run(['curl', '--noproxy', '*', '-sS', '--tlsv1.3', '--tls-max', '1.3',
                    '--connect-to', f'{name}:443:{host}:{port}', '--connect-timeout', '5',
                    '--max-time', '10', '-o', '/dev/null', '-w', '%{http_code}',
                    f'https://{name}/'], 12)
                results.append({'target': target, 'sni': name, 'ok': ok, 'http': out})
            except Exception as exc:
                results.append({'ok': False, 'error': type(exc).__name__})
    return results


def main(recover=False):
    STATE.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    state = json.loads(STATE.read_text()) if STATE.exists() else {}
    now = time.time()
    with ThreadPoolExecutor(max_workers=3) as pool:
        dns_ok = list(pool.map(dns, ['www.google.com', 'api.anthropic.com', 'www.yahoo.com']))
    # No DNS-dependent recovery when basic external TCP connectivity is down.
    internet, _ = run(['curl', '--noproxy', '*', '-sS', '--connect-timeout', '5', '--max-time', '8',
                      '-o', '/dev/null', 'https://1.1.1.1/'], 10)
    panel, status = run(['curl', '--noproxy', '*', '-sS', '--max-time', '5', '-o', '/dev/null',
                        '-w', '%{http_code}', 'http://127.0.0.1:8000/dashboard/'], 7)
    panel = panel and status == '200'
    inspected, container = run(['docker', 'inspect', '--format',
        '{{.State.Status}} {{if .State.Health}}{{.State.Health.Status}}{{end}}', 'marzban'])
    dns_bad = not any(dns_ok) and internet
    service_bad = inspected and not panel and (container == 'running unhealthy' or container.startswith('exited'))
    recover_dns = eligible(state, 'dns', dns_bad, now)
    recover_service = eligible(state, 'service', service_bad, now)
    actions = []
    if recover and recover_dns:
        active, _ = run(['systemctl', 'is-active', 'systemd-resolved'])
        if active:
            run(['resolvectl', 'flush-caches'])
            if not dns('www.google.com'):
                ok, _ = run(['systemctl', 'restart', 'systemd-resolved'])
                actions.append({'action': 'restart-resolved', 'command_ok': ok})
            else:
                actions.append({'action': 'flush-dns', 'command_ok': True})
    elif recover and recover_service:
        ok, _ = run(['docker', 'restart', '--time', '20', 'marzban'], 45)
        actions.append({'action': 'restart-marzban', 'command_ok': ok})
    if actions:
        state.update(last_action=now, actions=state.get('actions', 0) + 1)
    try:
        reality = probe_reality()
    except Exception as exc:
        reality = [{'ok': False, 'error': type(exc).__name__}]
    report = {'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'dns': dns_ok, 'internet': internet, 'panel': panel, 'container': container,
              'reality': reality, 'actions': actions, 'recovery_enabled': recover,
              'attention': not all(dns_ok) or not panel or not reality or not all(x['ok'] for x in reality)}
    state['last_report'] = report
    tmp = STATE.with_suffix('.tmp')
    tmp.write_text(json.dumps(state, indent=2))
    tmp.chmod(0o600)
    tmp.replace(STATE)
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--recover', action='store_true', help='Enable bounded recovery only when explicitly authorized')
    main(parser.parse_args().recover)
