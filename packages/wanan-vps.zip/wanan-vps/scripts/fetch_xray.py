#!/usr/bin/env python3
"""Download fixed official Xray artifacts into a NEW directory; never install services."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import urllib.request
import zipfile


def fetch(url, limit):
    req = urllib.request.Request(url, headers={'User-Agent': 'wanan-vps/1'})
    with urllib.request.urlopen(req, timeout=90) as response:
        data = response.read(limit + 1)
    if len(data) > limit:
        raise ValueError('Download exceeds safety limit')
    return data


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--version', required=True)
    ap.add_argument('--arch', choices=('amd64', 'arm64'), required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    if not re.fullmatch(r'v\d+\.\d+\.\d+', args.version) or args.out.exists():
        raise ValueError('Require a fixed version and a new directory')
    asset = 'Xray-linux-64.zip' if args.arch == 'amd64' else 'Xray-linux-arm64-v8a.zip'
    url = f'https://github.com/XTLS/Xray-core/releases/download/{args.version}/{asset}'
    data = fetch(url, 128 * 1024 * 1024)
    actual = hashlib.sha256(data).hexdigest()
    manifest = fetch(url + '.dgst', 64 * 1024).decode()
    if actual not in {s.lower() for s in re.findall(r'\b[0-9a-fA-F]{64}\b', manifest)}:
        raise ValueError('Official release checksum mismatch')
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        required = ('xray', 'geoip.dat', 'geosite.dat')
        if not all(name in archive.namelist() for name in required):
            raise ValueError('Release layout changed; inspect before proceeding')
        if sum(archive.getinfo(name).file_size for name in required) > 256 * 1024 * 1024:
            raise ValueError('Unexpected archive size')
        args.out.mkdir(parents=True, mode=0o700)
        for name in required:
            path = args.out / name
            with path.open('xb') as file:
                file.write(archive.read(name))
            path.chmod(0o755 if name == 'xray' else 0o644)
    (args.out / 'release.json').write_text(json.dumps({'version': args.version, 'sha256': actual, 'source': url}, indent=2) + '\n')
    print(json.dumps({'directory': str(args.out.resolve()), 'version': args.version, 'sha256': actual}))


if __name__ == '__main__':
    main()
