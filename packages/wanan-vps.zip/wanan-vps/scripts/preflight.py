#!/usr/bin/env python3
"""Read-only server inventory, excluding secret files and request logs."""
import argparse
import json
from pathlib import Path
import platform
import shutil
import subprocess
from render import validate


def command(args):
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=12)
        return {'exit': r.returncode, 'stdout': r.stdout.strip()}
    except (OSError, subprocess.TimeoutExpired) as error:
        return {'error': type(error).__name__}


def fresh_reasons(checks):
    reasons = []
    if checks['existing_deployment_paths']:
        reasons.append('existing deployment paths')
    if checks['planned_port_probe'].get('exit') != 0 or checks['planned_port_probe'].get('stdout'):
        reasons.append('occupied/unverifiable planned ports')
    if checks['docker_installed']:
        # An unavailable daemon cannot prove that there are no old containers.
        if checks['containers'].get('exit') != 0 or checks['containers'].get('stdout'):
            reasons.append('existing/unverifiable Docker containers, including stopped')
        # Do not enter apt/systemctl new-host steps on a pre-existing Docker host.
        reasons.append('pre-existing Docker requires reviewed coexistence branch')
    if checks['nginx_installed'] or checks['nginx_sites']:
        reasons.append('pre-existing Nginx requires reviewed coexistence branch')
    return reasons


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--config', type=Path, required=True)
    ap.add_argument('--require-fresh', action='store_true')
    args = ap.parse_args()
    cfg = validate(json.loads(args.config.read_text(encoding='utf-8')))
    existing = [p for p in ('/opt/marzban', '/var/lib/marzban', '/etc/nginx/sites-available/wanan-vps',
                            '/etc/nginx/sites-enabled/wanan-vps', '/etc/x-ui', '/usr/local/x-ui')
                if Path(p).exists() or Path(p).is_symlink()]
    sites = Path('/etc/nginx/sites-enabled')
    checks = {'platform': platform.platform(), 'architecture': platform.machine(), 'cpus': __import__('os').cpu_count(),
              'os_release': Path('/etc/os-release').read_text() if Path('/etc/os-release').exists() else 'Unavailable',
              'memory': command(['free', '-m']), 'disk': command(['df', '-h', '/']), 'swap': command(['swapon', '--show']),
              'listeners': command(['ss', '-lntup']),
              'docker_installed': shutil.which('docker') is not None,
              'nginx_installed': shutil.which('nginx') is not None,
              'containers': command(['docker', 'ps', '-a', '--format', '{{.Names}} {{.Image}} {{.Status}}']),
              'docker_active': command(['systemctl', 'is-active', 'docker']),
              'docker_enabled': command(['systemctl', 'is-enabled', 'docker']),
              'nginx_active': command(['systemctl', 'is-active', 'nginx']),
              'nginx_enabled': command(['systemctl', 'is-enabled', 'nginx']),
              'nginx_sites': [str(p) for p in sites.iterdir()] if sites.exists() else [],
              'firewall': command(['ufw', 'status']), 'existing_deployment_paths': existing}
    ports = {cfg['node_port'], cfg['panel_port'], 8000}
    if cfg['http_subscription']:
        ports.add(cfg['http_subscription_port'])
    checks['planned_port_probe'] = command(['ss', '-H', '-lnt', 'sport = ' + ' or sport = '.join(':' + str(p) for p in sorted(ports))])
    print(json.dumps(checks, ensure_ascii=False, indent=2))
    # This guard is not permission to alter other installed services.
    if args.require_fresh and fresh_reasons(checks):
        raise SystemExit('STOP: ' + '; '.join(fresh_reasons(checks)) + '. Use reviewed coexistence/migration, not fresh steps.')


if __name__ == '__main__':
    main()
