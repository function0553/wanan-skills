#!/usr/bin/env python3
"""Harmless synthetic /sub probe; inspect logs locally without printing request data."""
import argparse
import datetime
import json
from pathlib import Path
import secrets
import subprocess
from urllib.parse import urlsplit


def contains_marker(data, marker):
    return marker.encode() in data


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--public-base', required=True, help='Authorized HTTPS panel origin only')
    ap.add_argument('--container', default='marzban')
    ap.add_argument('--nginx-log', type=Path, nargs='+', required=True, help='Exact active access/error log files')
    ap.add_argument('--cacert', type=Path, help='Exact trusted certificate, never insecure mode')
    args = ap.parse_args()
    base = urlsplit(args.public_base)
    if base.scheme != 'https' or not base.hostname or base.username or base.password or base.path not in ('', '/') or base.query or base.fragment:
        raise ValueError('Require a credential-free authorized HTTPS origin')
    positions = {p: p.stat().st_size for p in args.nginx_log}  # Missing/unreadable logs must not pass.
    marker = 'wanan-privacy-' + secrets.token_hex(16)
    since = datetime.datetime.now(datetime.timezone.utc).isoformat()
    for origin in ('http://127.0.0.1:8000', args.public_base.rstrip('/')):
        command = ['curl', '--noproxy', '*', '-sS', '--connect-timeout', '5', '--max-time', '12',
                   '-o', '/dev/null', '-w', '%{http_code}']
        if origin.startswith('https://') and args.cacert:
            command += ['--cacert', str(args.cacert)]
        response = subprocess.run(command + [origin + '/sub/' + marker + '/clash-meta'],
                                  capture_output=True, timeout=15)
        if response.returncode or response.stdout.strip() == b'000':
            raise ValueError('Synthetic probe could not reach application/HTTPS; no privacy pass claimed')
    logs = subprocess.run(['docker', 'logs', '--since', since, '--tail', '1001', args.container],
                          capture_output=True, timeout=15)
    if logs.returncode or len((logs.stdout + logs.stderr).splitlines()) >= 1001:
        raise ValueError('Docker logs unavailable or probe window too noisy; no privacy pass claimed')
    leaked = contains_marker(logs.stdout + logs.stderr, marker)
    for p, start in positions.items():
        size = p.stat().st_size
        if size < start or size - start > 10 * 1024 * 1024:
            raise ValueError('Nginx logs rotated or too noisy during probe; retry in controlled window')
        with p.open('rb') as file:
            file.seek(start)
            leaked = leaked or contains_marker(file.read(10 * 1024 * 1024), marker)
    print(json.dumps({'synthetic_marker_logged': leaked, 'scope': 'synthetic internal and HTTPS request lines only'}))
    if leaked:
        raise SystemExit(2)


if __name__ == '__main__':
    main()
