#!/usr/bin/env python3
"""Whitelist-only distribution. Never include generated configs or private evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
FILES = ['SKILL.md', 'agents/openai.yaml', 'references/HANDOFF.md',
         'assets/site.example.json', 'assets/ai-split.yml', 'assets/watchdog.service', 'assets/watchdog.timer', 'assets/run-marzban.py',
         'scripts/render.py', 'scripts/preflight.py', 'scripts/fetch_xray.py', 'scripts/backup.py',
         'scripts/watchdog.py', 'scripts/Start-Antigravity-Proxy.ps1', 'scripts/test_bundle.py', 'scripts/package.py',
         'scripts/check_log_privacy.py']


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    if args.out.exists():
        raise ValueError('Refuse overwriting an existing delivery archive')
    content = {}
    for name in FILES:
        source = ROOT / name
        if source.is_symlink() or not source.is_file():
            raise ValueError('Missing or symlinked distribution file: ' + name)
        data = source.read_bytes()
        text = data.decode('utf-8-sig')
        if re.search(r'192\.220\.\d+\.\d+|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|/sub/[A-Za-z0-9_-]{12,}', text):
            raise ValueError('Possible original server identity/private material in: ' + name)
        content[name] = data
    manifest = {'name': 'wanan-vps', 'version': '1.0.1', 'date': '2026-10-12',
                'validation': 'offline only; no VPS deployment performed by package creation',
                'files': {name: hashlib.sha256(data).hexdigest() for name, data in content.items()}}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.out, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in content.items():
            archive.writestr('wanan-vps/' + name, data)
        archive.writestr('wanan-vps/PACKAGE-MANIFEST.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    # Independently verify bytes and exact membership after writing.
    with zipfile.ZipFile(args.out) as archive:
        if archive.testzip() is not None:
            raise ValueError('Corrupted archive')
        assert set(archive.namelist()) == {'wanan-vps/' + name for name in content} | {'wanan-vps/PACKAGE-MANIFEST.json'}
        for name, data in content.items():
            assert archive.read('wanan-vps/' + name) == data
    print(json.dumps({'archive': str(args.out.resolve()), 'sha256': hashlib.sha256(args.out.read_bytes()).hexdigest(),
                      'files': len(content) + 1, 'bytes': args.out.stat().st_size}))


if __name__ == '__main__':
    main()
