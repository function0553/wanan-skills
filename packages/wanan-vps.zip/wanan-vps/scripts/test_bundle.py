"""Offline regression; uses synthetic nodes and never connects to a VPS."""
import base64
from contextlib import closing
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import sqlite3
import types
import unittest
from unittest.mock import patch

import jinja2
import yaml
from render import ROOT, build, parse_keys, validate
import render
import backup
import preflight

spec = importlib.util.spec_from_file_location('wanan_watchdog', Path(__file__).with_name('watchdog.py'))
watchdog = importlib.util.module_from_spec(spec)
spec.loader.exec_module(watchdog)
launcher_spec = importlib.util.spec_from_file_location('wanan_launcher', ROOT / 'assets/run-marzban.py')
launcher = importlib.util.module_from_spec(launcher_spec)
launcher_spec.loader.exec_module(launcher)
privacy_spec = importlib.util.spec_from_file_location('wanan_privacy', ROOT / 'scripts/check_log_privacy.py')
privacy = importlib.util.module_from_spec(privacy_spec)
privacy_spec.loader.exec_module(privacy)


class BundleTests(unittest.TestCase):
    def setUp(self):
        self.c = json.loads((ROOT / 'assets/site.example.json').read_text(encoding='utf-8'))
        self.key = base64.urlsafe_b64encode(bytes(range(32))).decode().rstrip('=')

    def rendered(self, c=None):
        files = build(copy.deepcopy(c or self.c), self.key, self.key)
        node = {'name': 'synthetic-only', 'type': 'vless', 'server': (c or self.c)['server_ip'],
                'port': (c or self.c)['node_port'], 'uuid': '00000000-0000-4000-8000-000000000001'}
        env = jinja2.Environment(autoescape=False)
        env.filters['except'] = lambda value, *keys: {k: v for k, v in value.items() if k not in keys}
        env.filters['yaml'] = lambda value: yaml.safe_dump(value, allow_unicode=True, sort_keys=False).rstrip()
        text = env.from_string(files['ai-split.yml']).render(conf={'proxies': [node]}, proxy_remarks=[node['name']])
        return files, yaml.safe_load(text)

    def test_https_default_and_no_http_listener(self):
        files, _ = self.rendered()
        self.assertIn('XRAY_SUBSCRIPTION_URL_PREFIX=https://panel.example.com:20816', files['.env'])
        self.assertNotIn('listen 20817;', files['nginx.conf'])

    def test_http_opt_in_only_subscriptions(self):
        self.c['http_subscription'] = True
        files, _ = self.rendered()
        http = files['nginx.conf'].split('listen 20817;')[1]
        self.assertIn('location ^~ /sub/', http)
        self.assertIn('location / { return 404; }', http)
        self.assertIn('XRAY_SUBSCRIPTION_URL_PREFIX=http://203.0.113.10:20817', files['.env'])

    def test_private_application_and_pinned_container(self):
        files, _ = self.rendered()
        compose = yaml.safe_load(files['docker-compose.yml'])
        service = compose['services']['marzban']
        self.assertEqual(service['image'], self.c['marzban_image'])
        self.assertIn('UVICORN_HOST=127.0.0.1', files['.env'])
        self.assertNotIn('SUDO_PASSWORD', files['.env'])
        self.assertEqual(service['logging']['options']['max-size'], '10m')

    def test_template_uses_same_node_and_two_groups(self):
        _, profile = self.rendered()
        self.assertEqual(profile['proxies'][0]['server'], self.c['server_ip'])
        self.assertEqual([g['name'] for g in profile['proxy-groups']], ['欧洲chatgpt和Google特供', 'AI-PROXY'])
        for group in profile['proxy-groups']:
            self.assertEqual(group['proxies'], ['synthetic-only'])

    def test_rule_order_and_server_loop_avoidance(self):
        _, p = self.rendered()
        rules = p['rules']
        self.assertEqual(rules[0], 'IP-CIDR,203.0.113.10/32,DIRECT,no-resolve')
        self.assertEqual(rules[-1], 'MATCH,AI-PROXY')
        cn = rules.index('GEOSITE,cn,DIRECT')
        for item in ('DOMAIN-SUFFIX,chatgpt.com,欧洲chatgpt和Google特供',
                     'DOMAIN-SUFFIX,googleapis.com,欧洲chatgpt和Google特供',
                     'DOMAIN-SUFFIX,anthropic.com,AI-PROXY', 'DOMAIN-SUFFIX,kiro.dev,AI-PROXY'):
            self.assertLess(rules.index(item), cn)

    def test_dns_and_rule_mode_no_forced_tun(self):
        _, p = self.rendered()
        self.assertEqual(p['mode'], 'rule')
        self.assertFalse(p['allow-lan'])
        self.assertFalse(p['ipv6'])
        self.assertFalse(p['tun']['enable'])
        self.assertIn('#欧洲chatgpt和Google特供', p['dns']['nameserver-policy']['+.googleapis.com'])
        self.assertIn('#AI-PROXY', p['dns']['nameserver-policy']['+.claude.ai'])

    def test_no_request_url_logging_on_subscriptions(self):
        files, _ = self.rendered()
        location = files['nginx.conf'].split('location ^~ /sub/')[1].split('location /')[0]
        self.assertIn('access_log off', location)
        self.assertIn('error_log /dev/null', location)

    def test_reality_private_destinations_denied(self):
        files, _ = self.rendered()
        core = json.loads(files['xray_config.json'])
        self.assertEqual(core['inbounds'][0]['port'], self.c['node_port'])
        self.assertEqual(core['inbounds'][0]['settings']['clients'], [])
        self.assertEqual(core['routing']['rules'][0]['outboundTag'], 'BLOCK')

    def test_new_short_ids_each_generation(self):
        a, _ = self.rendered()
        b, _ = self.rendered()
        def short(files):
            return json.loads(files['xray_config.json'])['inbounds'][0]['streamSettings']['realitySettings']['shortIds']
        self.assertNotEqual(short(a), short(b))

    def test_key_format_old_and_new(self):
        for public_label in ('Public key', 'PublicKey', 'Password (PublicKey)', 'Password'):
            self.assertEqual(parse_keys('PrivateKey: ' + self.key + '\n' + public_label + ': ' + self.key), (self.key, self.key))
        with self.assertRaises(ValueError):
            parse_keys('PrivateKey: not-a-key\nPassword: not-a-key')

    def test_refuse_mutable_images(self):
        self.c['marzban_image'] = 'gozargah/marzban:latest'
        with self.assertRaises(ValueError):
            validate(self.c)

    def test_refuse_ports_conflicts_and_bool_ports(self):
        for value in (15900, 8000, True, 0, 65536):
            c = copy.deepcopy(self.c)
            c['panel_port'] = value
            with self.assertRaises(ValueError):
                validate(c)
        for value in (True, 1234):
            c = copy.deepcopy(self.c)
            c['server_ip'] = value
            with self.assertRaises(ValueError):
                validate(c)

    def test_refuse_nginx_env_injection(self):
        for key, value in (('panel_host', 'ok.example; listen 8000;'), ('certificate', '/tmp/a\nfoo'),
                           ('reality_sni', 'example.com\nXRAY_JSON=a'), ('certificate_key', '/root/../bad'),
                           ('panel_host', '2001:db8::1')):
            c = copy.deepcopy(self.c)
            c[key] = value
            with self.assertRaises(ValueError):
                validate(c)

    def test_three_failure_gate(self):
        state = {}
        self.assertFalse(watchdog.eligible(state, 'dns', True, 10000))
        self.assertFalse(watchdog.eligible(state, 'dns', True, 10300))
        self.assertTrue(watchdog.eligible(state, 'dns', True, 10600))

    def test_recovery_cooldown_shared_budget_and_reset(self):
        state = {}
        watchdog.eligible(state, 'dns', True, 10000)
        state.update(dns_failures=3, last_action=10000, actions=1)
        self.assertFalse(watchdog.eligible(state, 'dns', True, 11000))
        self.assertTrue(watchdog.eligible(state, 'dns', True, 12000))
        state['actions'] = 2
        self.assertFalse(watchdog.eligible(state, 'dns', True, 13000))
        self.assertFalse(watchdog.eligible(state, 'dns', False, 14000))
        self.assertEqual(state['dns_failures'], 0)

    def test_cli_refuses_existing_stage_before_running_xray(self):
        with tempfile.TemporaryDirectory() as temp:
            work = Path(temp)
            cfg = work / 'site.json'
            cfg.write_text(json.dumps(self.c))
            with patch('sys.argv', ['render.py', '--config', str(cfg), '--out', str(work), '--xray', 'nonexistent']), \
                    patch.object(render.subprocess, 'run') as runner:
                with self.assertRaises(ValueError):
                    render.main()
                runner.assert_not_called()

    def test_observe_mode_never_recovers_even_when_eligible(self):
        with tempfile.TemporaryDirectory() as temp:
            state = Path(temp) / 'state.json'
            invoked = []
            def fake_run(args, timeout=12):
                invoked.append(args)
                if args[:2] == ['docker', 'inspect']:
                    return True, 'running unhealthy'
                if args[0] == 'curl' and 'http://127.0.0.1:8000/dashboard/' in args:
                    return False, '503'
                return True, ''
            with patch.object(watchdog, 'STATE', state), patch.object(watchdog, 'dns', return_value=False), \
                    patch.object(watchdog, 'run', side_effect=fake_run), \
                    patch.object(watchdog, 'eligible', return_value=True), \
                    patch.object(watchdog, 'probe_reality', return_value=[{'ok': False}]), patch('builtins.print'):
                watchdog.main(False)
            report = json.loads(state.read_text())['last_report']
            self.assertEqual(report['actions'], [])
            self.assertFalse(report['recovery_enabled'])
            self.assertFalse(any('restart' in args for args in invoked))

    def inventory(self):
        return {'existing_deployment_paths': [], 'planned_port_probe': {'exit': 0, 'stdout': ''},
                'docker_installed': False, 'nginx_installed': False, 'nginx_sites': [],
                'containers': {'exit': 0, 'stdout': ''}}

    def test_stopped_containers_require_coexistence(self):
        checks = self.inventory()
        checks.update(docker_installed=True, containers={'exit': 0, 'stdout': 'old-marzb Exited'})
        self.assertTrue(any('including stopped' in item for item in preflight.fresh_reasons(checks)))

    def test_inaccessible_docker_is_not_empty_host(self):
        checks = self.inventory()
        checks.update(docker_installed=True, containers={'exit': 1, 'stdout': ''})
        self.assertTrue(preflight.fresh_reasons(checks))

    def test_existing_nginx_and_compose_directory_stop_fresh(self):
        checks = self.inventory()
        checks['nginx_installed'] = True
        self.assertTrue(preflight.fresh_reasons(checks))
        checks = self.inventory()
        checks['existing_deployment_paths'] = ['/opt/marzban']
        self.assertTrue(preflight.fresh_reasons(checks))

    def backup_fixture(self, work):
        db = work / 'live.sqlite3'
        with closing(sqlite3.connect(db)) as c:
            c.execute('CREATE TABLE example (value INTEGER)')
            c.execute('INSERT INTO example VALUES (7)')
            c.commit()
        env = work / 'env'
        env.write_text('SQLALCHEMY_DATABASE_URL=sqlite:///' + db.resolve().as_posix())
        return db, {'env': env}

    def test_missing_checkpoint_file_does_not_create_success(self):
        with tempfile.TemporaryDirectory() as temp:
            work = Path(temp)
            db, sources = self.backup_fixture(work)
            sources['missing-required'] = work / 'absent'
            out = work / 'checkpoint'
            with self.assertRaises(ValueError):
                backup.create_checkpoint(db, sources, out)
            self.assertFalse(out.exists())

    def test_mismatched_db_mapping_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            work = Path(temp)
            db, sources = self.backup_fixture(work)
            sources['env'].write_text('SQLALCHEMY_DATABASE_URL=sqlite:///' + (work / 'different').resolve().as_posix())
            with self.assertRaises(ValueError):
                backup.create_checkpoint(db, sources, work / 'checkpoint')

    def test_checkpoint_reopens_isolated_copy_and_leaves_live_untouched(self):
        with tempfile.TemporaryDirectory() as temp:
            work = Path(temp)
            db, sources = self.backup_fixture(work)
            with patch('builtins.print'):
                backup.create_checkpoint(db, sources, work / 'checkpoint')
            for path in (db, work / 'checkpoint/db.sqlite3'):
                with closing(sqlite3.connect(path)) as c:
                    self.assertEqual(c.execute('SELECT value FROM example').fetchall(), [(7,)])
            self.assertEqual(json.loads((work / 'checkpoint/manifest.json').read_text())['sqlite_integrity'], 'ok')

    def test_launcher_enforces_no_access_log_without_replacing_main_flow(self):
        calls = []
        fake = types.ModuleType('uvicorn')
        fake.run = lambda *args, **kwargs: calls.append((args, kwargs))
        original = fake.run
        with tempfile.TemporaryDirectory() as temp:
            main = Path(temp) / 'main.py'
            main.write_text('import uvicorn\nuvicorn.run("main:app", access_log=True, workers=1)\n')
            with patch.dict('sys.modules', {'uvicorn': fake}), patch('builtins.print'):
                launcher.launch(main)
        self.assertFalse(calls[0][1]['access_log'])
        self.assertEqual(calls[0][1]['workers'], 1)
        self.assertIs(fake.run, original)

    def test_privacy_probe_detects_marker_without_outputting_logs(self):
        marker = 'synthetic-only-marker'
        self.assertTrue(privacy.contains_marker(b'GET /sub/' + marker.encode() + b'/ HTTP/1.1', marker))
        self.assertFalse(privacy.contains_marker(b'healthy operational log', marker))

    def test_compose_keeps_migration_and_runs_log_wrapper(self):
        files, _ = self.rendered()
        command = yaml.safe_load(files['docker-compose.yml'])['services']['marzban']['command']
        self.assertIn('alembic upgrade head && exec python /var/lib/marzban/run-marzban.py', command)
        self.assertIn('run-marzban.py', files)


if __name__ == '__main__':
    unittest.main()
