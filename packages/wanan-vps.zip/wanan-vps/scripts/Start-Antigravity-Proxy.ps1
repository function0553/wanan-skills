[CmdletBinding()]
param(
    # Full credential-free HTTP(S) proxy URL takes precedence over the registry.
    [string]$ProxyUrl,

    # Loopback HTTP proxy port override; 0 means use Windows Internet Settings.
    [int]$ProxyPort = 0
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Add-ExecutableCandidate {
    param(
        [Parameter(Mandatory = $true)][System.Collections.Generic.List[string]]$Paths,
        [string]$Path
    )

    if ([string]::IsNullOrWhiteSpace($Path)) { return }
    $candidate = [Environment]::ExpandEnvironmentVariables($Path.Trim())

    $quoted = [regex]::Match($candidate, '^\s*"(?<path>[^"]+\.exe)"', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if ($quoted.Success) {
        $candidate = $quoted.Groups['path'].Value
    }
    else {
        $plain = [regex]::Match($candidate, '^\s*(?<path>.+?\.exe)(?:,\s*-?\d+)?\s*$', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
        if ($plain.Success) { $candidate = $plain.Groups['path'].Value }
    }

    if (Test-Path -LiteralPath $candidate -PathType Container) {
        $candidate = Join-Path $candidate 'Antigravity.exe'
    }
    if ((Test-Path -LiteralPath $candidate -PathType Leaf) -and -not $Paths.Contains($candidate)) {
        [void]$Paths.Add($candidate)
    }
}

function Get-AntigravityExecutable {
    $paths = New-Object 'System.Collections.Generic.List[string]'

    if ($env:LOCALAPPDATA) {
        Add-ExecutableCandidate -Paths $paths -Path (Join-Path $env:LOCALAPPDATA 'Programs\antigravity\Antigravity.exe')
        Add-ExecutableCandidate -Paths $paths -Path (Join-Path $env:LOCALAPPDATA 'Programs\Antigravity\Antigravity.exe')
    }

    $appPathKeys = @(
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\Antigravity.exe',
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\Antigravity.exe',
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\Antigravity.exe'
    )
    foreach ($keyPath in $appPathKeys) {
        if (Test-Path -LiteralPath $keyPath) {
            try {
                $key = Get-Item -LiteralPath $keyPath
                Add-ExecutableCandidate -Paths $paths -Path ([string]$key.GetValue(''))
            }
            catch { }
        }
    }

    $uninstallRoots = @(
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'
    )
    foreach ($root in $uninstallRoots) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        try { $entries = @(Get-ChildItem -LiteralPath $root -ErrorAction Stop) }
        catch { continue }
        foreach ($entry in $entries) {
            try {
                $key = Get-Item -LiteralPath $entry.PSPath
                $displayName = [string]$key.GetValue('DisplayName')
                if ($displayName -notmatch '(?i)antigravity') { continue }

                Add-ExecutableCandidate -Paths $paths -Path ([string]$key.GetValue('InstallLocation'))
                Add-ExecutableCandidate -Paths $paths -Path ([string]$key.GetValue('DisplayIcon'))
            }
            catch { }
        }
    }

    foreach ($programRoot in @(
        [Environment]::GetEnvironmentVariable('ProgramFiles'),
        [Environment]::GetEnvironmentVariable('ProgramFiles(x86)')
    )) {
        if ($programRoot) {
            Add-ExecutableCandidate -Paths $paths -Path (Join-Path $programRoot 'Antigravity')
            Add-ExecutableCandidate -Paths $paths -Path (Join-Path $programRoot 'Google\Antigravity')
        }
    }

    $command = Get-Command 'Antigravity.exe' -ErrorAction SilentlyContinue
    if ($command -and $command.Source) {
        Add-ExecutableCandidate -Paths $paths -Path $command.Source
    }

    foreach ($path in $paths) {
        try {
            $version = (Get-Item -LiteralPath $path).VersionInfo
            if ($version.ProductName -match '(?i)antigravity') { return $path }
        }
        catch { }
    }

    throw 'Could not find a registered Antigravity installation. Install Antigravity for this account or use a standard registered install path.'
}

function Test-AntigravityRunning {
    try {
        $processes = @(Get-CimInstance Win32_Process -Filter "name='Antigravity.exe' OR name='language_server.exe'" -ErrorAction Stop)
    }
    catch {
        throw 'Could not safely check whether Antigravity is running; refusing to launch.'
    }

    foreach ($process in $processes) {
        if ($process.Name -ieq 'Antigravity.exe') { return $true }
        if ($process.Name -ieq 'language_server.exe') {
            $path = [string]$process.ExecutablePath
            if ([string]::IsNullOrWhiteSpace($path) -or
                $path -match '(?i)\\antigravity\\resources\\bin\\language_server\.exe$') {
                return $true
            }
        }
    }
    return $false
}

function Get-RegistryProxyEndpoint {
    $settingsPath = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings'
    try {
        $settings = Get-ItemProperty -LiteralPath $settingsPath -Name ProxyEnable, ProxyServer -ErrorAction Stop
    }
    catch {
        throw 'Could not read the current-user Windows Internet Settings proxy. Supply -ProxyUrl or -ProxyPort.'
    }

    if ([int]$settings.ProxyEnable -ne 1) {
        throw 'Windows system proxy is not enabled. Supply -ProxyUrl or -ProxyPort for the intended proxy.'
    }

    $raw = [string]$settings.ProxyServer
    if ([string]::IsNullOrWhiteSpace($raw)) {
        throw 'Windows system proxy has no static ProxyServer value. Supply -ProxyUrl or -ProxyPort.'
    }

    $endpoints = New-Object System.Collections.Generic.List[object]
    foreach ($item in ($raw -split ';')) {
        $segment = $item.Trim()
        if (-not $segment) { continue }

        $mapping = [regex]::Match(
            $segment,
            '^(?<kind>https?|ftp|socks)=',
            [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
        )
        if ($mapping.Success) {
            $kind = $mapping.Groups['kind'].Value.ToLowerInvariant()
            if ($kind -eq 'ftp' -or $kind -eq 'socks') { continue }
            $endpoint = $segment.Substring($mapping.Length)
        }
        else {
            $endpoint = $segment
        }

        $match = [regex]::Match(
            $endpoint,
            '^(?:(?<proxyScheme>https?)://)?(?<host>127\.0\.0\.1|localhost|\[::1\]):(?<port>\d{1,5})$',
            [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
        )
        if (-not $match.Success) {
            throw 'Windows ProxyServer is not a simple loopback HTTP(S) proxy. Supply -ProxyUrl or -ProxyPort for the intended proxy.'
        }

        $hostName = $match.Groups['host'].Value.ToLowerInvariant()
        if ($hostName -eq 'localhost') { $hostName = '127.0.0.1' }
        $port = [int]$match.Groups['port'].Value
        if ($port -lt 1 -or $port -gt 65535) {
            throw 'Windows ProxyServer contains an invalid port.'
        }

        $scheme = $match.Groups['proxyScheme'].Value.ToLowerInvariant()
        if (-not $scheme) { $scheme = 'http' }
        [void]$endpoints.Add([pscustomobject]@{
            Host   = $hostName
            Port   = $port
            Scheme = $scheme
        })
    }

    if ($endpoints.Count -eq 0) {
        throw 'No HTTP(S) loopback endpoint was found in Windows ProxyServer. Supply -ProxyUrl or -ProxyPort.'
    }

    $hosts = @($endpoints | ForEach-Object Host | Sort-Object -Unique)
    $ports = @($endpoints | ForEach-Object Port | Sort-Object -Unique)
    $schemes = @($endpoints | ForEach-Object Scheme | Sort-Object -Unique)
    if ($hosts.Count -ne 1 -or $ports.Count -ne 1 -or $schemes.Count -ne 1) {
        throw 'Windows ProxyServer maps to different endpoints. Supply -ProxyUrl or -ProxyPort for the intended proxy.'
    }

    $hostName = [string]$hosts[0]
    $scheme = [string]$schemes[0]
    $port = [int]$ports[0]
    return [pscustomobject]@{
        Uri      = [uri](('{0}://{1}:{2}' -f $scheme, $hostName, $port))
        Source   = 'Windows Internet Settings registry'
        Loopback = $true
    }
}

function Test-LoopbackListener {
    param([Parameter(Mandatory = $true)][uri]$Uri)

    $hostName = $Uri.Host.Trim('[', ']')
    $address = if ($hostName -eq '::1') {
        [System.Net.IPAddress]::IPv6Loopback
    }
    else {
        [System.Net.IPAddress]::Loopback
    }

    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $client.Connect($address, $Uri.Port)
        return $client.Connected
    }
    catch {
        return $false
    }
    finally {
        $client.Dispose()
    }
}

try {
    if ($ProxyPort -lt 0 -or $ProxyPort -gt 65535) {
        throw 'ProxyPort must be 1-65535, or 0 to discover from Windows Internet Settings.'
    }
    if (-not [string]::IsNullOrWhiteSpace($ProxyUrl) -and $ProxyPort -gt 0) {
        throw 'Use either -ProxyUrl or -ProxyPort, not both.'
    }

    if (Test-AntigravityRunning) {
        Write-Warning 'Antigravity or its language server is still running. Save your work, exit Antigravity normally, then run this script again. No process was stopped.'
        return
    }

    $appExe = Get-AntigravityExecutable
    if (-not [string]::IsNullOrWhiteSpace($ProxyUrl)) {
        $uri = $null
        if (-not [uri]::TryCreate($ProxyUrl.Trim(), [UriKind]::Absolute, [ref]$uri) -or
            $uri.Scheme -notin @('http', 'https') -or
            -not [string]::IsNullOrEmpty($uri.UserInfo) -or
            $uri.AbsolutePath -notin @('', '/') -or
            -not [string]::IsNullOrEmpty($uri.Query) -or
            -not [string]::IsNullOrEmpty($uri.Fragment)) {
            throw 'ProxyUrl must be a credential-free http:// or https:// proxy authority, without a path, query, or fragment.'
        }
        $proxy = [pscustomobject]@{
            Uri      = $uri
            Source   = '-ProxyUrl override'
            Loopback = [uri]::IsLoopback($uri)
        }
    }
    elseif ($ProxyPort -gt 0) {
        $proxy = [pscustomobject]@{
            Uri      = [uri]("http://127.0.0.1:$ProxyPort")
            Source   = '-ProxyPort override'
            Loopback = $true
        }
    }
    else {
        $proxy = Get-RegistryProxyEndpoint
    }

    if ($proxy.Loopback -and -not (Test-LoopbackListener -Uri $proxy.Uri)) {
        throw 'No TCP listener accepted a loopback connection at the selected proxy endpoint. Start the intended proxy or override it with -ProxyUrl / -ProxyPort.'
    }

    # Do not put credentials in ProxyUrl: Electron receives this switch on its command line.
    $proxyValue = $proxy.Uri.GetLeftPart([UriPartial]::Authority)
    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $startInfo.FileName = $appExe
    $startInfo.WorkingDirectory = Split-Path -Parent $appExe
    $startInfo.UseShellExecute = $false
    $startInfo.Arguments = "--proxy-server=$proxyValue --proxy-bypass-list=localhost;127.0.0.1;[::1]"

    # These settings exist only in Antigravity's process tree. No persistent or system
    # environment, registry, app setting, or TLS-verification setting is changed.
    foreach ($name in @('HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY')) {
        $startInfo.EnvironmentVariables[$name] = $proxyValue
    }
    $startInfo.EnvironmentVariables['NO_PROXY'] = 'localhost,127.0.0.1,::1'

    $child = [System.Diagnostics.Process]::Start($startInfo)
    if ($null -eq $child) { throw 'Windows did not return a process handle for Antigravity.' }
    $childId = $child.Id
    $child.Dispose()

    Write-Host "Started Antigravity (PID $childId) using $($proxy.Source). Proxy settings are process-scoped."
    if (-not $proxy.Loopback) {
        Write-Host 'Remote proxy reachability was not pretested.'
    }
}
catch {
    Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
}
