#!/usr/bin/env python3
"""Generate NEW deployment staging files. No SSH, service or firewall mutations."""
import argparse
import base64
import ipaddress
import json
from pathlib import Path
import re
import secrets
import subprocess

ROOT = Path(__file__).resolve().parents[1]
ALLOWED = {'server_ip', 'ssh_port', 'node_port', 'panel_port', 'http_subscription',
           'http_subscription_port', 'panel_host', 'certificate', 'certificate_key',
           'marzban_image', 'xray_version', 'reality_sni', 'reality_target', 'reality_target_port'}


def hostname(value):
    if not isinstance(value, str) or len(value) > 253:
        raise ValueError('Invalid hostname')
    try:
        address = ipaddress.ip_address(value)
        if address.version != 4:
            raise ValueError('IPv6 literal authorities are outside this IPv4 baseline')
        return value
    except ValueError:
        pass
    if not all(re.fullmatch(r'[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?', s) for s in value.split('.')):
        raise ValueError('Invalid hostname')
    return value.lower()


def validate(c):
    if set(c) != ALLOWED:
        raise ValueError('Configuration keys differ from site.example.json')
    # Current templates are deliberately IPv4-only, matching the tested baseline.
    if not isinstance(c['server_ip'], str) or ipaddress.ip_address(c['server_ip']).version != 4:
        raise ValueError('This baseline supports an IPv4 server address')
    for key in ('ssh_port', 'node_port', 'panel_port', 'http_subscription_port', 'reality_target_port'):
        if type(c[key]) is not int or not 1 <= c[key] <= 65535:
            raise ValueError('Invalid port: ' + key)
    if len({c[k] for k in ('ssh_port', 'node_port', 'panel_port', 'http_subscription_port')}) != 4:
        raise ValueError('SSH/node/panel/subscription ports must differ')
    if 8000 in {c[k] for k in ('ssh_port', 'node_port', 'panel_port', 'http_subscription_port')}:
        raise ValueError('8000 is reserved for the internal application')
    if type(c['http_subscription']) is not bool:
        raise ValueError('http_subscription must be boolean')
    for key in ('panel_host', 'reality_sni', 'reality_target'):
        c[key] = hostname(c[key])
    for key in ('certificate', 'certificate_key'):
        value = c[key]
        if not isinstance(value, str) or not re.fullmatch(r'/[A-Za-z0-9_./-]+', value) or '..' in value.split('/'):
            raise ValueError('Invalid absolute certificate path')
    if c['certificate'] == c['certificate_key']:
        raise ValueError('Certificate and private key paths must differ')
    if not re.fullmatch(r'gozargah/marzban@sha256:[0-9a-f]{64}', c['marzban_image']):
        raise ValueError('Require a reviewed immutable official image digest')
    if not re.fullmatch(r'v\d+\.\d+\.\d+', c['xray_version']):
        raise ValueError('Require a fixed Xray release version')
    return c


def parse_keys(output):
    fields = dict(line.split(':', 1) for line in output.splitlines() if ':' in line)
    private = (fields.get('PrivateKey') or fields.get('Private key') or '').strip()
    public = (fields.get('Password (PublicKey)') or fields.get('PublicKey') or
              fields.get('Public key') or fields.get('Password') or '').strip()
    for value in (private, public):
        if not re.fullmatch(r'[A-Za-z0-9_-]{43}', value) or len(base64.urlsafe_b64decode(value + '=')) != 32:
            raise ValueError('Unrecognized X25519 output; stop rather than infer keys')
    return private, public


def nginx(c):
    common = '''        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Host $http_host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto https;
'''
    result = f'''map $http_upgrade $wanan_connection_upgrade {{
    default upgrade;
    '' close;
}}
limit_req_zone $binary_remote_addr zone=wanan_login:1m rate=6r/m;
server {{
    listen {c['panel_port']} ssl;
    server_name {c['panel_host']};
    ssl_certificate {c['certificate']};
    ssl_certificate_key {c['certificate_key']};
    ssl_protocols TLSv1.2 TLSv1.3;
    client_max_body_size 16m;
    server_tokens off;
    add_header Referrer-Policy same-origin always;
    add_header X-Content-Type-Options nosniff always;
    location = /api/admin/token {{
        limit_req zone=wanan_login burst=5 nodelay;
{common}    }}
    location ^~ /sub/ {{
        access_log off;
        error_log /dev/null;
        add_header Cache-Control "private, no-store" always;
{common}    }}
    location / {{
{common}        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection $wanan_connection_upgrade;
        proxy_read_timeout 3600s;
        proxy_buffering off;
    }}
}}
'''
    if c['http_subscription']:
        result += f'''server {{
    listen {c['http_subscription_port']};
    server_name {c['server_ip']};
    server_tokens off;
    location ^~ /sub/ {{
        access_log off;
        error_log /dev/null;
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $http_host;
        proxy_set_header X-Forwarded-Proto http;
        proxy_set_header X-Real-IP $remote_addr;
        add_header Cache-Control "private, no-store" always;
    }}
    location / {{ return 404; }}
}}
'''
    return result


def build(c, private, public):
    validate(c)
    prefix = (f"http://{c['server_ip']}:{c['http_subscription_port']}" if c['http_subscription'] else
              f"https://{c['panel_host']}:{c['panel_port']}")
    xray = {'log': {'loglevel': 'warning'},
            'dns': {'servers': ['https://1.1.1.1/dns-query', 'https://8.8.8.8/dns-query'], 'queryStrategy': 'UseIPv4'},
            'inbounds': [{'tag': 'VLESS Reality TCP', 'listen': '0.0.0.0', 'port': c['node_port'], 'protocol': 'vless',
                          'settings': {'clients': [], 'decryption': 'none'},
                          'streamSettings': {'network': 'tcp', 'security': 'reality',
                                             'realitySettings': {'show': False, 'dest': f"{c['reality_target']}:{c['reality_target_port']}",
                                                                 'xver': 0, 'serverNames': [c['reality_sni']], 'privateKey': private,
                                                                 'publicKey': public, 'shortIds': [secrets.token_hex(8)]}},
                          'sniffing': {'enabled': True, 'destOverride': ['http', 'tls', 'quic'], 'routeOnly': True}}],
            'outbounds': [{'tag': 'DIRECT', 'protocol': 'freedom', 'settings': {'domainStrategy': 'UseIPv4'}},
                          {'tag': 'BLOCK', 'protocol': 'blackhole'}],
            'routing': {'domainStrategy': 'IPIfNonMatch', 'rules': [{'type': 'field', 'ip': ['geoip:private'], 'outboundTag': 'BLOCK'}]}}
    env = '\n'.join(['UVICORN_HOST=127.0.0.1', 'UVICORN_PORT=8000',
                     'XRAY_JSON=/var/lib/marzban/xray_config.json',
                     'SQLALCHEMY_DATABASE_URL=sqlite:////var/lib/marzban/db.sqlite3',
                     'XRAY_EXECUTABLE_PATH=/var/lib/marzban/xray-core/xray',
                     'XRAY_ASSETS_PATH=/var/lib/marzban/xray-core',
                     'XRAY_SUBSCRIPTION_URL_PREFIX=' + prefix,
                     'CUSTOM_TEMPLATES_DIRECTORY=/var/lib/marzban/templates/',
                     'CLASH_SUBSCRIPTION_TEMPLATE=ai-split.yml', 'SUB_UPDATE_INTERVAL=6',
                     'USERS_AUTODELETE_DAYS=-1', 'JWT_ACCESS_TOKEN_EXPIRE_MINUTES=1440']) + '\n'
    compose = f'''services:
  marzban:
    image: {c['marzban_image']}
    container_name: marzban
    restart: unless-stopped
    env_file: .env
    command: ["sh", "-ec", "alembic upgrade head && exec python /var/lib/marzban/run-marzban.py"]
    network_mode: host
    volumes:
      - /var/lib/marzban:/var/lib/marzban
    logging:
      driver: json-file
      options:
        max-size: 10m
        max-file: "3"
    ulimits:
      nofile:
        soft: 65536
        hard: 65536
    healthcheck:
      test: ["CMD", "python", "-c", "import urllib.request; urllib.request.urlopen('http://127.0.0.1:8000/dashboard/', timeout=8)"]
      interval: 60s
      timeout: 10s
      retries: 3
      start_period: 60s
'''
    template = (ROOT / 'assets/ai-split.yml').read_text(encoding='utf-8').replace('__SERVER_IPV4__', c['server_ip'])
    return {'.env': env, 'docker-compose.yml': compose, 'xray_config.json': json.dumps(xray, indent=2) + '\n',
            'ai-split.yml': template, 'nginx.conf': nginx(c), 'site.json': json.dumps(c, indent=2) + '\n',
            'run-marzban.py': (ROOT / 'assets/run-marzban.py').read_text(encoding='utf-8')}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--config', required=True, type=Path)
    ap.add_argument('--out', required=True, type=Path)
    ap.add_argument('--xray', required=True, type=Path, help='Previously downloaded and checksum-verified Xray executable')
    args = ap.parse_args()
    c = validate(json.loads(args.config.read_text(encoding='utf-8')))
    if args.out.exists():
        raise ValueError('Staging directory already exists; never overwrite existing generated keys')
    binary = str(args.xray.resolve(strict=True))
    version = subprocess.run([binary, 'version'], capture_output=True, text=True, check=True, timeout=10).stdout
    if not re.search(r'\b' + re.escape(c['xray_version'][1:]) + r'\b', version):
        raise ValueError('Xray binary does not match the configured release')
    raw = subprocess.run([binary, 'x25519'], capture_output=True, text=True, check=True, timeout=10).stdout
    files = build(c, *parse_keys(raw))
    args.out.mkdir(parents=True, mode=0o700)
    for name, content in files.items():
        path = args.out / name
        with path.open('x', encoding='utf-8', newline='\n') as file:
            file.write(content)
        path.chmod(0o600)
    print('Generated staging directory: ' + str(args.out.resolve()))
    print('Contains NEW PRIVATE KEYS. Do not publish or use this generator for migration.')


if __name__ == '__main__':
    try:
        main()
    except ValueError as exc:
        # Our validation messages identify the field, never its secret value.
        raise SystemExit('Stopped: ' + str(exc))
    except (OSError, subprocess.SubprocessError) as exc:
        raise SystemExit('Stopped: ' + type(exc).__name__ + '; inspect paths/tool versions. Captured key output is not printed.')
