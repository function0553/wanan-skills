#!/usr/bin/env python3
"""Consistent private Marzban checkpoint; no service stop, no sharing or remote access."""
import argparse
from contextlib import closing
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3


def create_checkpoint(db, sources, out):
    if not db.is_file() or out.exists() or len(out.resolve().parts) < 3:
        raise ValueError('Require an existing Marzban DB and a new specific backup directory')
    if not all(Path(p).is_file() for p in sources.values()):
        raise ValueError('Required checkpoint file missing; refusing partial-success report')
    # Confirm the actual persistent DB matches this SQLite-only helper.
    env = Path(sources['env']).read_text(encoding='utf-8')
    values = dict(line.split('=', 1) for line in env.splitlines() if '=' in line and not line.lstrip().startswith('#'))
    values = {k.strip(): v.strip().strip('"\'') for k, v in values.items()}
    dsn = values.get('SQLALCHEMY_DATABASE_URL', '')
    if not dsn.startswith('sqlite:///') or not Path(dsn[len('sqlite:///'):]).is_absolute():
        raise ValueError('Only an explicitly configured absolute SQLite database is supported; use DB-native backup otherwise')
    if Path(dsn[len('sqlite:///'):]).resolve() != db.resolve():
        raise ValueError('Configured database differs from the selected backup DB; stop and inspect volume mapping')
    os.umask(0o077)
    out.mkdir(mode=0o700, parents=True)
    out.chmod(0o700)
    # URI mode=ro prevents silently creating an empty source database.
    with closing(sqlite3.connect(db.resolve().as_uri() + '?mode=ro', uri=True, timeout=15)) as source:
        if source.execute('PRAGMA integrity_check').fetchall() != [('ok',)]:
            raise ValueError('Source database integrity check failed')
        with closing(sqlite3.connect(out / 'db.sqlite3')) as target:
            source.backup(target)
            target.commit()
    # Open the isolated copy, never restore over the live DB for a test.
    with closing(sqlite3.connect((out / 'db.sqlite3').resolve().as_uri() + '?mode=ro', uri=True)) as restored:
        if restored.execute('PRAGMA integrity_check').fetchall() != [('ok',)]:
            raise ValueError('Backup database integrity check failed')
    for name, value in sources.items():
        shutil.copy2(value, out / name)
    # Certbot private keys, other applications and Nginx sites are deliberately
    # not guessed. Operator inventories and backs them up per the handoff.
    hashes = {}
    for path in out.iterdir():
        if path.is_file():
            path.chmod(0o600)
            hashes[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
    (out / 'manifest.json').write_text(json.dumps({'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                                                'files': hashes, 'sqlite_integrity': 'ok', 'contains_secrets': True,
                                                'scope': 'application checkpoint only; exact Nginx/TLS/core artifacts require separate backup'}, indent=2))
    print('PRIVATE application checkpoint created: ' + str(out.resolve()))
    print('Also back up the exact active Nginx site, TLS key/certificate, and core version before migration.')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True, help='New exact private backup directory')
    ap.add_argument('--database', type=Path, default=Path('/var/lib/marzban/db.sqlite3'))
    ap.add_argument('--config-dir', type=Path, default=Path('/opt/marzban'))
    ap.add_argument('--data-dir', type=Path, default=Path('/var/lib/marzban'))
    args = ap.parse_args()
    sources = {'env': args.config_dir / '.env', 'docker-compose.yml': args.config_dir / 'docker-compose.yml',
               'xray_config.json': args.data_dir / 'xray_config.json',
               'ai-split.yml': args.data_dir / 'templates/ai-split.yml',
               'xray-release.json': args.data_dir / 'xray-core/release.json'}
    if sources['docker-compose.yml'].is_file() and 'run-marzban.py' in sources['docker-compose.yml'].read_text():
        sources['run-marzban.py'] = args.data_dir / 'run-marzban.py'
    create_checkpoint(args.database, sources, args.out)


if __name__ == '__main__':
    main()
