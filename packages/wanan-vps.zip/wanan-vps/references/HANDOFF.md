# wanan-vps：完整搭建、运维与交接手册

整理：2026-10-12（Asia/Singapore）。这是可分享的**脱敏通用流程**，不是某台服务器的当前在线状态。目标为获授权 Ubuntu 24.04 VPS + Docker Marzban/SQLite + Xray VLESS Reality + Nginx + Mihomo/Clash Verge。端口可改，示例是 SSH 25906、节点 15900、HTTPS 面板 20816；不是要求所有 VPS 固定使用这些端口。

本包不含 root/面板密码、用户 UUID、住宅上游、第三方订阅、证书私钥、数据库或某位用户的节点配置。`203.0.113.10`、`panel.example.com` 是文档专用示例，必须替换。包内镜像 digest/Xray v26.3.27 是既有部署的**历史兼容基线**，不是“最新/最安全”推荐；正式部署前复核官方发布、安全公告、架构和模板兼容。不要只升级其中一项后沿用所有老字段。

## 目录与交付方式

将整个 `wanan-vps` 文件夹安装到当前客户端支持的个人技能目录；此工作流的本机安装位置为 `.codex/skills/wanan-vps`。也可置于项目支持的 `.agents/skills/wanan-vps`，以实际 Codex 技能发现配置为准。调用 `$wanan-vps`，提供**新的**目标和范围。不要只分享 SKILL.md 丢掉资产；只需要人工阅读时可单独分享本手册。

建议给接手助手的指令：

> 使用 $wanan-vps，在我授权的 Ubuntu 24.04 VPS 部署 Marzban + Reality，国内直连、OpenAI/Google 专组、Claude/Kiro 与其他国外走本 VPS。先检查已有服务和端口，不借其他订阅，不公开明文订阅，完成后测试真实出口、业务页面和客户端泄露，并写目标交接文档。服务器登录信息通过安全渠道另给。

## 1. 先明确目标与保护边界

确认 IP、SSH 端口/用户名、认证方式、主机指纹、架构、发行版、RAM/CPU/磁盘/实际月流量；已有 3x-ui/Marzban/网站/Docker/其他 VPN、允许维护窗口、必须保持不变的订阅；面板是否公开及允许访问来源；域名或 IP 证书；用户数、客户端/内核版本、到期/流量预算。

2C2G 不需要为纯代理额外装远程桌面、Firefox、MySQL 或 Redis。8个账号不等于8人重度并发已验收；容量取决于流量、协议、连接数、CPU/RAM与出口质量。2GiB swap 仅为 OOM 缓冲，不能算2GiB额外RAM，持续换页会慢。

连接使用明确的自定义 SSH 端口，并核验提供商控制台/已记录主机密钥。首次信任与主机密钥变化是两件事，不能自动接受变更。

```sh
ssh -p SSH_PORT USER@SERVER_IP
```

Windows 用 PowerShell，Mac 用终端；不要把密码写命令参数、聊天分享或脚本。工具可使用 MCP/SSH/SFTP，但必须知道自己连接的是哪台机器。下面步骤都在**目标 Ubuntu** 上操作；本包整理时没有执行这些在线变更。

## 2. 只读预检及迁移分支

把包上传至一个新目录（例如 `/root/wanan-vps`），用编辑器复制并填写 `assets/site.example.json` 为 `/root/wanan-vps-site.json`。其中没有密码，端口必须唯一，内部8000不能作为公网面板端口。先检查：

```sh
cd /root/wanan-vps
python3 scripts/preflight.py --config /root/wanan-vps-site.json --require-fresh
```

检查 `/etc/os-release`、架构、监听、现有部署路径、Docker、UFW、云安全组。预检返回 STOP 时不要越过；预检缺少工具/权限不是“确认空机”。已有网站即使不占本次端口，也应记录 Nginx 配置并只添加独立站点，不删除默认站点或重启所有服务。

fresh门禁现在检查完整部署目录、Docker所有容器（包括stopped）、Docker/Nginx是否已安装与active/enabled、Nginx启用站点及计划端口。已有Docker/Nginx就进入人工审查共存分支，不能自动执行下一节apt/systemctl新建清单。Docker已安装但daemon不可访问也要停止，不能把“ps失败”当“没有旧容器”。

### 共享宿主共存（不是fresh）

先保存原Docker/Nginx active/enabled状态、unit、容器清单/启动时间/重启计数、已监听业务与Nginx站点快照；只复用已经运行且获准使用的Docker，不enable/start/restart原daemon。确需启动原来停止的服务或安装会自启动的软件时另获维护授权。逐项确认目标目录/容器名/项目名空闲；共享主机使用明确独立Compose项目，名字冲突必须停止，不能接管旧marzban容器。默认生成器/巡检为标准marzban布局，改变项目/容器名需对应调整并测试，不硬套。

在共享Nginx只添加独立新站点/端口，nginx -t后经维护授权graceful reload；其他站点配置/服务启用状态不改。若“绝对零影响”不可证明，明确说明维护风险而不是承诺。该分支不运行fresh安装清单，实施计划与回退由负责助手按实际服务清单生成。

### 已有 3x-ui

识别真实 unit（通常 x-ui.service）、安装/数据库目录和监听端口。用 SQLite backup API 备份其实际数据库；复制 `/etc/x-ui`、`/usr/local/x-ui`、systemd unit 与启动状态到带日期的 root-only 目录，校验备份存在且可读。目录/版本不符就调整，不能硬套。得到停机授权后才能停旧 unit；不要卸载或删数据。新服务失败则只停新服务，再恢复原 unit 与原启动状态。3x-ui 用户不会自动出现在 Marzban，不要宣称旧订阅原样迁移成功。

### 已有 Marzban / 要求订阅不变

禁止运行下文“新建安装”或重新生成 Reality 密钥。先：

```sh
python3 scripts/backup.py --out /root/marzban-backups/NEW_EXACT_TIMESTAMP
```

该目录含敏感数据，700/文件600，不分发；补充备份实际 Nginx 站点、TLS 私钥/证书、Xray release、当前镜像、Compose、unit、防火墙。SQLite backup API 保证数据库一致快照，不是直接复制正在写的 sqlite 文件；若配置修改同时发生，需要冻结配置变更以取得相互匹配的配置/DB检查点。

backup.py仅处理显式绝对路径SQLite；支持 `--database`、`--config-dir`、`--data-dir`，核对.env配置与选择的DB路径，必须文件缺失立即失败，并检查源/隔离备份数据库integrity。MySQL/PostgreSQL、相对DSN或不明volume映射必须采用对应DB-native方案，不能生成空DB或声称已备份。这里的成功只代表应用检查点，Nginx/TLS与实际core仍须补齐，再做隔离恢复演练；任一步失败不继续升级。

保持 DB、JWT/订阅签名、UUID、端口、prefix/path、Reality 私钥/publicKey/shortIds。跨 IP 迁移不能保证用户手里的 IP URL 不变；需要原地址仍可到达的域名/转发方案或客户端重新导入。恢复旧数据前先备份新状态；恢复 DB 时只停 Marzban，避免 WAL 与恢复文件混用，不能用 docker prune/全盘恢复/清空防火墙。

## 3. 固定版本与依赖

仅干净且获授权目标安装 Ubuntu 官方仓库基础依赖：

以下仅适用于预检确认此前没有Docker/Nginx的fresh主机；保存原服务启用状态，若已有任一服务则走上一节共存流程，不运行这些启用命令。

```sh
apt-get update
apt-get install -y docker.io docker-compose-v2 nginx curl openssl ca-certificates python3 ufw
systemctl enable --now docker
docker compose version
```

镜像固定官方 digest；先核验 CPU 架构对应镜像清单、拉取成功和帮助/API/模板。包内历史 digest 不保证 ARM64 兼容，ARM 目标须换经核验的对应 digest。不要使用不经审查的 `latest` 或 `curl | bash`。安装依赖可能启动 Nginx 占80，证书 standalone前先检查，不能为此停别人的站点。

对精确digest检查Entrypoint/Cmd/WorkingDir与main.py、Uvicorn启动契约。本包的command保持Alembic迁移，再运行只关闭Uvicorn access_log的包装器；仅适用于Entrypoint为空、工作目录含main.py和alembic的官方布局。不一致即停下适配，不猜测。包装器保留运维日志，不打印或记录请求行；不能仅关闭Nginx日志就宣称应用不记订阅token。

下载到**新暂存目录**，架构按 `uname -m` 选 amd64 或 arm64；版本必须与 site.json 一致：

```sh
python3 scripts/fetch_xray.py --version v26.3.27 --arch amd64 --out /root/wanan-vps-core
/root/wanan-vps-core/xray version
```

只从 XTLS/Xray-core 固定官方发行下载，校验 `.dgst` SHA256，提取已知 xray/geoip.dat/geosite.dat。校验失配、版式变化、资产缺失时停止，不改用随机镜像站或跳过校验。旧 `network: tcp`/`dest` 字段按历史基线验证；新版 Xray 支持字段可能变化，应按选定版本官方说明与 `run -test` 核验。

若没有 swap 且磁盘充足，可在授权后创建**全新** `/swapfile` 2GiB，600，mkswap/swapon，并以编辑器向 fstab添加一次正确条目；已有 swap不覆盖、不叠加重复条目。不为提速盲目新增swap。

## 4. TLS 与 DNS：避免用户依赖 SSH

### 推荐：域名 + 可信证书

DNS 新增 **A** 记录指向本 VPS，不把 IP 填进 NS。无正确 IPv6时不添加 AAAA。代理端点若使用 Cloudflare等DNS服务，必须确认协议/端口是否支持代理；IP Reality节点通常直接连接 VPS，不能让普通 HTTP CDN 承载 TCP Reality。

使用服务商官方 ACME 工具或 Certbot 签发，保持私钥600。HTTP-01需要云侧与主机80/tcp可达并命中正确webroot；已有网站用独立 challenge location + webroot，验证 Nginx 后 graceful reload，不停旧站点。选择 DNS-01 时 DNS API凭据另存安全渠道。将证书的实际路径填写 site.json，后面 Nginx引用它。

### 不用域名

IP + 可信 IP SAN证书可以公开提供 TLS；IP与证书 SAN必须一致。Let’s Encrypt 已支持短期 IP证书，Certbot5.4+ webroot流程可用；有效期约160小时，必须验证自动续期和 Nginx部署钩子。不要沿用“没域名只能自签”的旧结论。按当期官方版本/配置准备隔离工具环境，示例：

```sh
# webroot须已由本站点正确服务；先实际验证80端口与challenge路径。
certbot certonly --staging --preferred-profile shortlived --webroot \
  --webroot-path /var/www/wanan-vps-acme --ip-address YOUR_PUBLIC_IPV4
# staging证书不被浏览器信任；测试通过后按官方流程签发生产证书。
certbot renew --dry-run
```

如果现有Certbot过旧，用隔离venv安装经审核固定版本，不在系统Python全局pip覆盖依赖。生产签发与staging的存储/证书lineage必须核对，以 `certbot certificates` 返回的真实路径写入 site.json。生产签发不只是把staging证书复制成新文件名。续期计划保持 Certbot实际执行路径、生产lineage、同一webroot；reload钩子仅 `nginx -t && systemctl reload nginx`，不能重启Docker/Marzban。定时续期与实际有效期监控必须由负责人维护，手动签发不等于已经自动续期。

IP自签证书只是受控临时方案，需要客户端信任；不能让助手绕过浏览器警告、`curl -k`、skip-cert-verify或关闭TLS验证来宣称验收。浏览器能打开自签面板不代表 Clash会信任订阅证书。

### 明文 HTTP订阅是显式选择

仅用户明确接受风险时把 site.json 的 `http_subscription` 设true；开放指定HTTP端口**仅 `/sub/`**，其他路径404，不用HTTP面板。链接含凭据，传输明文可能泄露UUID/节点，绝不在其中输入管理员密码；access/error日志不记录订阅URL。默认false，直接从可信HTTPS端口订阅。以后改变prefix会改变复制出来的订阅URL，升级时必须先核对“URL不变”要求。

## 5. 生成新配置与安装

先从 VPS到 Reality目标用正确SNI验证DNS、证书与 TLS1.3，不以HTTP403/429误判TLS失败；服务商握手不稳定时重新选择目标需要独立审批与客户端同步。Yahoo只是历史示例，绝非加速/地区解锁服务。

```sh
curl --tlsv1.3 --tls-max 1.3 --connect-timeout 5 --max-time 12 \
  -o /dev/null -w '%{http_code}\n' https://YOUR_REALITY_SNI/
python3 scripts/render.py --config /root/wanan-vps-site.json \
  --xray /root/wanan-vps-core/xray --out /root/wanan-vps-stage
```

render读取实际 Xray版本并生成**全新**x25519/short ID，兼容PrivateKey/PublicKey/Password(PublicKey)输出；格式未知停止，密钥不打印。生成目录700/文件600。不把输出目录放回技能包，也不对旧VPS重复render来“刷新规则”。

在迁移分支、已有 `.env`/DB/站点、端口冲突时以下命令不可运行。正式创建前再次核对目标；安装阶段不要恢复旧临时用户、硬编码IP或私人上游：

```sh
test ! -e /opt/marzban/.env
test ! -e /opt/marzban/docker-compose.yml
test ! -e /var/lib/marzban/db.sqlite3
test ! -e /var/lib/marzban/xray_config.json
test ! -e /etc/nginx/sites-available/wanan-vps
test ! -e /etc/nginx/sites-enabled/wanan-vps
install -d -m 700 /opt/marzban /var/lib/marzban /var/lib/marzban/templates /var/lib/marzban/xray-core
install -m 600 /root/wanan-vps-stage/.env /opt/marzban/.env
install -m 600 /root/wanan-vps-stage/docker-compose.yml /opt/marzban/docker-compose.yml
install -m 600 /root/wanan-vps-stage/xray_config.json /var/lib/marzban/xray_config.json
install -m 600 /root/wanan-vps-stage/ai-split.yml /var/lib/marzban/templates/ai-split.yml
install -m 600 /root/wanan-vps-stage/run-marzban.py /var/lib/marzban/run-marzban.py
install -m 755 /root/wanan-vps-core/xray /var/lib/marzban/xray-core/xray
install -m 644 /root/wanan-vps-core/geoip.dat /root/wanan-vps-core/geosite.dat /var/lib/marzban/xray-core/
install -m 600 /root/wanan-vps-core/release.json /var/lib/marzban/xray-core/release.json
XRAY_LOCATION_ASSET=/var/lib/marzban/xray-core /var/lib/marzban/xray-core/xray run -test -c /var/lib/marzban/xray_config.json
install -m 644 /root/wanan-vps-stage/nginx.conf /etc/nginx/sites-available/wanan-vps
ln -s /etc/nginx/sites-available/wanan-vps /etc/nginx/sites-enabled/wanan-vps
nginx -t
cd /opt/marzban
docker compose config --quiet
docker compose pull
docker compose up -d
```

逐条检查退出状态；在脚本中用 `set -eu`。install命令本身可覆盖文件，因此前置guard和操作者审核是必须的。不要复制整套别人的 `/etc/nginx` 或禁用默认站点。Nginx测试失败先移开**新加**链接，旧站点不动。内部 `127.0.0.1:8000/dashboard/`返回200后才 `systemctl reload nginx`；cold启动可能要60–120秒，container running不等于Python应用就绪。

云安全组与主机防火墙分别核验，只开实际 SSH端口、节点端口、面板端口（管理来源能限定就限定）；需要HTTP订阅才开其端口，ACME按所选验证机制开80。保留出站DNS/HTTPS与节点对外访问。不默认 ALL 1–65535、不对Ubuntu放RDP、不开放8000或无认证代理端口。

若首次启用UFW，先允许真实SSH端口/来源并保持已有会话、第二SSH连接与云控制台可恢复，再启用。已有防火墙按现状追加必要规则，不能 reset/flush 或覆盖其他业务规则。TCP Reality不需要默认开放所有入站UDP：客户端UDP在节点隧道中承载，宿主出站按用途验证。

## 6. 管理员、用户和稳定订阅

手工Compose安装未必有 `marzban`包装命令。用固定镜像内官方CLI创建管理员，先查help确认该版本命令：

```sh
docker exec -it marzban python marzban-cli.py admin create --help
docker exec -it marzban python marzban-cli.py admin create --sudo
```

交互输入**本次新用户名与强密码**；不使用包内示例/旧服务器密码。默认管理员通过CLI/DB创建，不在.env长期保存SUDO_PASSWORD。若镜像路径变更，从已审核的镜像工作目录确认CLI，不自行猜测DB字段。

正式交付订阅前，用无真实凭据的合成/sub请求验证应用/Docker/Nginx日志，不公开原始日志。标准日志位置仅为示例，先检查当前站点真实access/error日志；缺文件、无权限、探针未达TLS、日志轮转/截断都不能记为通过：

```sh
python3 /root/wanan-vps/scripts/check_log_privacy.py \
  --public-base https://YOUR_PANEL_HOST:YOUR_PANEL_PORT \
  --nginx-log /var/log/nginx/access.log /var/log/nginx/error.log
```

不支持的镜像/业务异常仍可能在其他应用日志输出敏感值，需要逐日志源确认。这条验证只覆盖合成请求行；不存在“所有未来错误都绝不泄露”的保证。已有实例若发现真实token留在日志，限制日志访问并与用户商议清理/撤销；保持原HTTP URL和保证传输保密不可同时满足，不擅自轮换破坏“URL不变”。

打开 `https://PANEL_HOST:PANEL_PORT/dashboard/`，新建每个人独立用户，启用 VLESS入站 `VLESS Reality TCP`，flow `xtls-rprx-vision`；按实际套餐设置月额度与到期，配额不是带宽或性能预留。Marzban动态管理用户，静态Xray `clients: []`不表示节点永远无用户。通过面板复制个人Clash Meta订阅，确认URL不包含127.0.0.1/旧IP，并从客户端实际导入。

新增用户继承服务端共享模板，不用手写所有UUID；管理员新增/续期/改配额即可。模板发布到服务器会影响下一次生成的订阅，不会自动刷新别人电脑。通知旧用户更新订阅并确认生效；没有客户端管理通道时不能声称“全员已强制推送”。用户名/令牌不公开截图或打进公共日志。

## 7. 规则、DNS和客户端体验

默认两个自定义业务组：

|用途|组|实际线路|
|---|---|---|
|OpenAI/ChatGPT、Google/Gemini/Antigravity/YouTube|欧洲chatgpt和Google特供|该用户自己的VPS节点|
|Claude、Kiro、其他国外|AI-PROXY|该用户自己的VPS节点|
|服务器本身/private/LAN、国内匹配项|DIRECT|客户端直连|

欧洲是沿用的名称，**不是欧洲IP**；内置GLOBAL也不是第三台服务器。模板不包含外国住宅上游或其他机场，不创建国内选择组。

规则顺序：服务器/LAN例外 → 可识别Claude进程 → 明确AI域名/配套认证 → 国外开发服务/GEOSITE → private/CN → MATCH代理。AI域名放CN兜底前，国内正常内容不让VPS转发；国内目标自己拒绝、超时、403或登录错误不一定是网络问题，所以不按HTTP状态自动切线路。需要例外时按已证实的具体域名添加规则，而不是所有失败请求自动代理。

ChatGPT文件/静态/实时连接包含openai.com/chatgpt.com/oaistatic.com/oaiusercontent.com等域名家族；Google有googleapis/gstatic/googleusercontent/antigravity等；Claude有anthropic/claude/claudeusercontent；Kiro按官方网络要求及AWS身份/服务域名覆盖。共享Google OAuth仍按Google域名分流，规则无法仅从域名判断是谁发起。AWS broad suffix会使部分非Kiro AWS也走代理，部署者应知道此副作用。未来新增域名以官方清单和实际连接日志为准，不承诺永久完整。

国内DoH优化国内CDN，国外/AI按所选组走代理DoH；节点解析/bootstrap与目标DNS是不同层，避免DNS通过节点、节点又等待该DNS的死循环。IPv6=false只约束核心，不替用户关闭系统IPv6。redir-host模式不需要同时放一堆无效fake-IP配置；模板保留的fake-IP子项在此模式下不是正在生效的fake-IP机制。

**规则模式才执行上述分流。** 用户坚持客户端GLOBAL时，无法同时承诺同一套客户端国内直连规则生效；应说明模式含义，不能把mode字段或组名当作实现。TUN默认关闭：遵守代理的浏览器使用系统代理即可；CLI/后台/UDP并不一定遵守系统代理。

### Antigravity / CLI尽量不依赖TUN

Windows正常退出应用后：

```powershell
# 端口填写本机实际Clash HTTP/mixed端口，不是VPS15900。
.\scripts\Start-Antigravity-Proxy.ps1 -ProxyPort 7897
```

脚本在有既有应用/语言服务器时拒绝启动，不强杀；只设置新进程树 HTTP_PROXY/HTTPS_PROXY/ALL_PROXY/NO_PROXY + Electron代理参数，不修改注册表、持久环境、其他VPN或TLS验证。版本升级后需重新验证后台确实继承代理；“脚本启动成功”不等于登录/模型任务通过。

Mac按真实安装路径和应用网络文档，退出既有进程后从终端启动真实可执行文件，使其继承进程级代理：

```sh
HTTP_PROXY=http://127.0.0.1:7897 HTTPS_PROXY=http://127.0.0.1:7897 \
ALL_PROXY=http://127.0.0.1:7897 NO_PROXY=localhost,127.0.0.1,::1 \
/Applications/Antigravity.app/Contents/MacOS/Antigravity \
  --proxy-server=http://127.0.0.1:7897
```

该路径/应用是否支持参数必须核实，示例不是Mac已实测结论。`open -a`可能复用旧进程而不继承新环境。Claude Code/Kiro/Codex和语言服务器分别按官方网络选项设置代理；不要因后台不读系统代理就强制全员改路由。某应用确实不支持代理时再评估TUN，不能保证所有应用都能只靠规则模式。

## 8. 分层验收：每层单独记结果

1. **静态/启动**：nginx -t、Compose config、Xray run -test通过；原业务配置/健康未变，node监听，内部面板200。
2. **控制面**：可信TLS、真实浏览器管理员登录、新增用户/到期配额、复制正确公网订阅；不是首页200就完成。
3. **订阅**：在客户端下载同一用户 `/sub/.../clash-meta`，确认真实IP、port、SNI、公钥/short ID、Vision、规则与DNS；Mihomo `-t`实际解析。不要在日志/截图输出令牌。
4. **数据面**：真实认证VLESS节点，代理访问IP探针，出口应为自己的VPS；DOMESTIC命中DIRECT，Google/OpenAI专组，Claude/Kiro AI-PROXY。测试核心绑定物理网卡，避免另一个VPN暗中提供出口。
5. **业务**：真实登录后 Gemini/Claude/ChatGPT/Antigravity/Kiro请求、文件、实时连接；网页“不支持地区”即失败，哪怕返回200。OpenAI `/v1/models`没有API key返回401通常是认证要求，不可为了200修改网络或贴别人的key。
6. **泄露**：逐客户端测试公网IPv4/IPv6、DNS、WebRTC候选；分别记录系统代理、TUN、规则/GLOBAL、浏览器权限/DoH设置。国内直连本来会暴露国内出口给国内站点，不能以此宣称所有网站统一一个IP。AI/国外需要确认没有意外直连。
7. **资源/并发**：按计划人数与负载重复测RTT/首包/吞吐、CPU、RAM、swap、重传/断流。压力探针会用流量，先告知时间/额度；单次测速不代表持续容量。

客户端命令示例（Windows用curl.exe，Linux/Mac用curl）：

```sh
curl --noproxy localhost --proxy http://127.0.0.1:7897 \
  --connect-timeout 8 --max-time 25 -w '\nHTTP=%{http_code} time=%{time_total}\n' https://api.ipify.org
curl --noproxy localhost --proxy http://127.0.0.1:7897 \
  --connect-timeout 8 --max-time 25 -o /dev/null -w '%{http_code}\n' https://www.google.com/generate_204
```

`-o /dev/null`在Windows改成NUL。核对curlverbose的代理CONNECT路径或支持版本的 `proxy_used`；不以模糊 `--noproxy ""`/命令未报错证明真走代理。有限次数用同一目标、同一物理链路、同一订阅，保留结果；不重写系统路由去“测试”，单IP直连/关闭另一VPN需单独授权与恢复。

系统代理无法可靠接管WebRTC UDP，不能靠服务器规则保证零泄露。选择浏览器官方WebRTC策略限制非代理UDP、应用自身代理或经过实际IPv4/IPv6/UDP路由验证的TUN方案；可能影响通话，需告知用户。单列“未验证/仍泄露”，不能把核心ipv6=false当全机防泄漏。网页定位/邮件图片EXIF/云连接器出站不由VPS全权控制。Dots或其他云端电脑的联网也不等于本机代理已接管。

## 9. 故障处理与经验

|现象|先核对|不要误操作|
|---|---|---|
|面板502|127.0.0.1:8000就绪、Nginx upstream、应用日志|反复换端口、开放所有端口|
|订阅复制127.0.0.1|prefix与当前面板入口/模板|把SSH隧道当全员部署|
|HTTPS订阅导入失败|证书SAN/有效期/客户端信任、实际URL|关闭TLS验证|
|订阅能导入但节点Timeout|真实入站/防火墙/SNI/密钥/UUID/账户、客户端物理链路|认为模板下载成功就节点可用|
|TCP秒连但SSH无banner|另一VPN/TUN拦截、物理网卡对照|把TCP成功当真实服务器响应|
|节点0/0|面板当前额度/到期和节点状态|直接推断流量耗尽|
|Gemini地区不支持|登录后页面、实际出口地区/Google认可情况、规则/DNS/IPv6|仅加域名或改Yahoo就宣布修好|
|Claude403/封禁提示|具体响应/账户/官方支持地区与申诉|轮换身份或保证防封号|
|原生IDE必须TUN|后台进程是否继承/支持应用代理|批量关闭别人VPN|
|Origin mismatch|实际Origin/Host/端口、普通表单响应头|接受任意null或关CSRF|
|远程浏览器卡顿|画面转发RTT、CPU配额、RAM/swap|把它混为纯VPN带宽瓶颈|

Gemini曾通过另一经授权对照线路能用、原VPS不能用，说明不能只凭“有美国IP”认为该IP一定符合平台判定；不能借用用户其他私人订阅作为全员修复。正式解决需要服务商纠正IP定位/更换合规可用出口（须新的授权和实际测试），不是规则可以凭空改变的属性。Reality目的域名只负责握手外观，访问Google的真实业务出口依旧是VPS。

曾复现门户 `no-referrer`让普通表单发送 `Origin:null`，与严格Origin校验冲突；修正为 `same-origin`后真实Edge登录通过，null/跨站/错端口仍拒绝。不要把那套自有门户源码混进基础代理，遇到同类问题时参考这条经验即可。

## 10. 保守性能优化与有限自愈

先记录原 sysctl、实际 `tc qdisc show dev ACTUAL_NIC`、CPU/RAM、RTT/首包/吞吐。`default_qdisc=fq`不代表运行网卡已经是fq；mq/fq_codel正常时保留。此前在线fq试验没有稳定收益，已回退；不能把研究候选说成已上线。BBR在现代内核不必为了启用而强行更换root队列。大下载场景Mux可能负收益；BBRv3换内核/重启、Hysteria2增协议与记账均是另一个审批/验收任务。

需要调优且得到授权时，仅确认内核支持后使用BBR；TCP自动缓冲上限16MiB和 `tcp_mtu_probing=1`是可对照候选，不是无条件万能参数。备份原值/原持久化文件，通过专属新sysctl文件进行单变量试验；回退只恢复这些值/移除自己的文件，不改qdisc、DNS或防火墙。按相同链路交替多轮测速，观察并发RAM/swap；历史约24%的小样本中位差异不作为保证收益。

可选watchdog使用标准库和系统工具，不新增庞大守护程序。默认 `python3 scripts/watchdog.py`只观察（但会记录状态/失败计数，不是纯只读）；安装 timer带 `--recover`才允许恢复。连续3次故障、30分钟冷却、每日总共最多2次恢复：DNS全部探针失败且外网可达，清正在运行的resolved缓存，仍失败才重启它；内部面板失败且容器明确unhealthy/exited才重启该容器。目标TLS异常仅记录，**不自动换SNI/端口/UUID/密钥**；没有外部告警通道或用户认证端到端保证。

该实现固定管理默认 `marzban`/8000/config路径；非默认部署应调整并测试，不装第二套watchdog与旧timer相互干扰。没有生产故障注入验收。文件/units已存在时拒绝覆盖；获恢复授权后新建安装：

```sh
test ! -e /usr/local/sbin/wanan-vps-watchdog.py
test ! -e /etc/systemd/system/wanan-vps-watchdog.service
test ! -e /etc/systemd/system/wanan-vps-watchdog.timer
install -m 700 scripts/watchdog.py /usr/local/sbin/wanan-vps-watchdog.py
install -m 644 assets/watchdog.service /etc/systemd/system/wanan-vps-watchdog.service
install -m 644 assets/watchdog.timer /etc/systemd/system/wanan-vps-watchdog.timer
systemctl daemon-reload
systemctl enable --now wanan-vps-watchdog.timer
journalctl -u wanan-vps-watchdog.service -n 30 --no-pager
```

停用 timer不必重启代理；先查oneshot是否正在执行。单站点限流或地区错误不触发全服务重启。监测DNS解析成功仅证明这个服务器解析器正常，不证明每个客户端DNS路径正常。

## 11. 发布、备份与回退交接

规则更新只改模板：备份旧模板/配置，检查实际render出的用户订阅和Mihomo解析；需要应用重载时安排窗口。先测试账户验收，再发布，原URL保持；用户刷新后才记录该客户端生效。新增代理组、上游或协议都要重新核对可用性、额度、记账、实际出口与过期时间，不能把过期住宅代理保留在自动选择组。

新安装失败：只停新Marzban，移走新Nginx站点链接后nginx -t/graceful reload；只撤销自己新增的入站规则，保留SSH与原业务，数据留存可恢复。已有Marzban升级失败：用配对的固定旧镜像/core/config/DB恢复；仅重启对应应用，考虑数据库迁移不可逆风险，不能只改回image却使用新版DB。证书续期失败不能随意改订阅为HTTP。

每台目标最终生成一个 `HANDOFF.md`，写：

- 目标标识/OS/架构/版本与日期、面板URL/端口、内部路径、主机/证书公钥指纹（不存私钥/密码/完整订阅）。
- 具体部署步骤、服务/规则/客户端的生效范围、谁负责证书续期和用户管理。
- 备份路径、已验证恢复步骤、在线维护窗口、订阅不变验收。
- 每层实际证据：服务、TLS/真实面板登录、用户订阅、Mihomo节点认证/路由/出口、业务页面任务、泄露/并发；未验收分开列。
- 踩坑与解决方法、客户端必要设置、未实施候选与限制。

当前技能包的离线测试和脱敏审核不能替代接收者的新VPS安装验收。不要向他人打包 `site.json`现场文件、`.env`、xray_config、DB、用户订阅、凭据日志或root检查点。

本包离线验收：26项配置/模板/规则/输入注入/拒绝覆盖/共存门禁/SQLite备份/应用日志包装/有限恢复政策回归、技能结构与本机Mihomo v1.19.31 `-t`检查；Windows客户端脚本经PowerShell语法解析。测试依赖Jinja2 3.1.6/PyYAML 6.0.2，可在单独QA环境安装，不是目标VPS基础部署额外依赖。Mihomo合成节点只做语法验证，不启动代理、不连接节点；不能称为新VPS连通成功。合成全数字short-id在YAML版本间曾被解释为数字，测试改为包含a–f的字符串；真实订阅应核查short-id最终是合法十六进制字符串。SQLite连接的with只管理事务而不负责关闭，Windows回归曾复现文件锁；现在用contextlib.closing显式关闭，隔离副本完整性检查通过。

## 12. 核验依据与清理范围

复用依据：[官方Marzban](https://github.com/Gozargah/Marzban)、[环境变量](https://github.com/Gozargah/Marzban/blob/master/.env.example)、[模板接口](https://github.com/Gozargah/Marzban/blob/master/app/templates/clash/default.yml)、[Xray发行](https://github.com/XTLS/Xray-core/releases)、[Xray配置](https://xtls.github.io/en/config/transport.html)、[Mihomo DNS](https://wiki.metacubex.one/en/config/dns/)、[Mihomo规则](https://wiki.metacubex.one/en/config/rules/)、[Kiro网络](https://kiro.dev/docs/privacy-and-security/firewalls/)、[Claude Code网络](https://code.claude.com/docs/en/network-config)、[IP证书/Certbot](https://letsencrypt.org/2026/03/11/shorter-certs-certbot)、[Linux TCP](https://docs.kernel.org/networking/ip-sysctl.html)、[BBR](https://github.com/google/bbr/blob/master/Documentation/bbr-quick-start.md)、[技能结构](https://developers.openai.com/plugins/build/skills)。动态文档/版本在未来运行时重新核对；这些链接不是授权。

日志启动契约核对：[Marzban main.py](https://github.com/Gozargah/Marzban/blob/master/main.py)、[官方Dockerfile](https://github.com/Gozargah/Marzban/blob/master/Dockerfile)。独立只读走查提出的共存门禁、必须备份完整性、应用access日志风险已并入本流程；走查未部署或拉取验证固定digest，包装器实机兼容性与日志合成探针仍是接收者部署验收项目。

本次整理把重复性能/规则/故障快照和未上线研究从原项目当前入口移至可恢复archive；保留原证据/源码，不删数据库、不改在线服务器。技能只采用脱敏通用脚本和模板：参数化目标、固定供应链、拒绝覆盖、私密暂存、默认可信HTTPS、有限恢复、分层验收。远程Firefox的受限试用/OOM历史单独保留，不作为纯VPS代理必装功能。
